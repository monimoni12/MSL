create definer = root@localhost view reservationdetails as
select `r`.`ReservationID` AS `ReservationID`,
       `c`.`CustomerName`  AS `CustomerName`,
       `rm`.`RoomID`       AS `RoomID`,
       `rt`.`RoomTypeName` AS `RoomTypeName`,
       `r`.`CheckInDate`   AS `CheckInDate`,
       `r`.`CheckOutDate`  AS `CheckOutDate`,
       `r`.`PeopleNum`     AS `PeopleNum`,
       `r`.`IsBreakfast`   AS `IsBreakfast`,
       `r`.`TotalPrice`    AS `TotalPrice`
from (((`jdbc`.`reservation` `r` join `jdbc`.`customers` `c`
        on ((`r`.`CustomerID` = `c`.`CustomerID`))) join `jdbc`.`room` `rm`
       on ((`r`.`RoomID` = `rm`.`RoomID`))) join `jdbc`.`roomtype` `rt` on ((`rm`.`RoomTypeID` = `rt`.`RoomTypeID`)));

